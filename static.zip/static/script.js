// Add event listener for "Enter" key in the input field
document.getElementById("user-input").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault(); // Prevents the default form submission action
        sendMessage(); // Call sendMessage function
    }
});

function sendMessage() {
    const userInput = document.getElementById("user-input").value;
    if (userInput.trim() === "") return;

    const chatBox = document.getElementById("chat-box");

    // Display user's message in the chat box
    const userMessage = document.createElement("div");
    userMessage.classList.add("user-message");
    userMessage.textContent = `Me: ${userInput}`;
    chatBox.appendChild(userMessage);

    // Clear the input field after sending
    document.getElementById("user-input").value = "";

    // Send the message to the server
    fetch("/chat", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: userInput })
    })
    .then(response => response.json())
    .then(data => {
        if (data.response) {
            // Display Medical Assistant's response in the chat box
            const aiMessage = document.createElement("div");
            aiMessage.classList.add("ai-message");
            aiMessage.textContent = `Medical Assistant: ${data.response}`;
            chatBox.appendChild(aiMessage);
        } else {
            console.error("Error:", data.error || "No response from server");
        }
    })
    .catch(error => console.error("Error:", error));
}
